#!/usr/bin/env python3
# -*- coding: utf-8 -*-
f=''
if __name__ == '__main__':
    s = "ИТЕРНЕТН"
    f += s[0]+s[4]+s[1]+s[2]+s[3]+s[7]+s[5]+s[6]
    print(f)